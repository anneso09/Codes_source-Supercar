<!-- Début du HTML -->
<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Demande d'essai </title>
 
    <!-- CSS de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!-- JAVASCRIPT de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href="a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>
 
<div class="container one p-5">
<?php
include("connexion.php");

$error_message = "";

if(isset($_GET['id_service'])) {
    $id_demande = htmlspecialchars($_GET['id_service']);

    $stmt = mysqli_prepare($bdd, "UPDATE service SET statut_service='Terminer' WHERE id_service=?");
    mysqli_stmt_bind_param($stmt, "i", $id_demande);
    
    if(mysqli_stmt_execute($stmt)) {
        header("Location: a_demandeservice_modifier.php");
        exit();
    } else {
        $error_message = "Failed to update service.";
    }
    mysqli_stmt_close($stmt);
}
?>


<?php
include("connexion.php");
$result = mysqli_query($bdd, "SELECT * FROM service ORDER BY id_service DESC");
?>

<!-- Début du HTML -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des demandes</title>
</head>
<body>
<a href="a_menu_demande_service.html">Retour</a>
    <table class="table">
        <thead>
            <tr>
                <th>Identifiant</th>
                <th>Type de service</th>
                <th>Date de la demande</th>
                <th>Statut</th>
                <th colspan="2">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        // Requête pour récupérer les données après la suppression
        $result = mysqli_query($bdd, "SELECT id_service, type_service, date_service, statut_service FROM service");
        while ($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['id_service']."</td>";
            echo "<td>".$res['type_service']."</td>";
            echo "<td>".$res['date_service']."</td>"; 
            echo "<td>".$res['statut_service']."</td>"; 
           echo "<td><a href=\"a_demandeservice_modifier.php?id_service=" . urlencode($res['id_service']) . "\">Terminer</a></td>";

            echo "<td><a href=\"a_demandeservice_suppr.php?id_service=$res[id_service]\" onClick=\"return confirm('Veuillez confirmer ?')\">Supprimer</a></td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</body>
</html>
