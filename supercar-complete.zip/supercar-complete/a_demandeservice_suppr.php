<?php 
include("connexion.php");
$id_service = $_GET['id_service'];
$result = mysqli_query($bdd, "DELETE FROM service WHERE id_service=$id_service");
header("Location:a_demandeservice_modifier.php");
?>