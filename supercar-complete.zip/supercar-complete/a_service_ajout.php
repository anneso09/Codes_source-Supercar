<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Ajout Service </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_menu.css" rel="stylesheet">

 

</HEAD>
<body>

    <!-- Partie PHP -->
    <?php
    include("connexion.php");
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $image = $_POST['image'];
        $type = $_POST['type_service'];
        $description = htmlspecialchars($_POST['description_service']);
        $image2 = 'images/' . $image;
        $insertQuery = "INSERT INTO p_service (image, type_service, description_service) VALUES ('$image2', '$type', '" . mysqli_real_escape_string($bdd, $description) . "')";
        // Execute the query using mysqli_query
        if (mysqli_query($bdd, $insertQuery)) {
            $status = "Ajout réussi";
        } else {
            $status = "Error: " . mysqli_error($bdd);
        }
    }
    ?>
    <!-- Fin du PHP -->

    <div class="container one p-5">
    <a href="a_menu_service.html">Retour</a>
        <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3 p-5">
                <h2 class="text-center fw-bold">Ajout de service</h2>
                <label for="type_service" class="form-label mt-3">Nom du service</label>
                <input type="text" class="form-control" name="type_service" placeholder="Exemple : Maintenance" required>


                <div class="my-3">
                    <label for="description" class="form-label">Description du service</label>
                    <textarea name="description_service" class="form-control" rows="3" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="inputGroupFile02" class="form-label">Télécharger l'image</label>
                    <input type="file" class="form-control" name="image" required>
                </div>

                <button type="submit" class="form-control button mt-4 red">Ajouter</button>
            </div>
            <div id="status">
                <?php
                // Affichage du message de statut dans le champ dédié
                if (isset($status)) {
                    echo $status;
                }
                ?>
            </div>
        </form>
    </div>

</body>

</html>