<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout Voitures</title>
    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- JAVASCRIPT de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link href = "a_style_menu.css" rel="stylesheet">
</head>
<body>

<?php
// Include the database connection
include("connexion.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $marque = $_POST["marque"];
    $modele = $_POST["modele"];
    $annee = $_POST["annee"];
    $logo_marque = $_POST["logo_marque"];
    $image_front = $_POST["image_front"];
    $image_interieur = $_POST["image_interieur"];
    $image_front = $_POST["image_front"];
    $image_back = $_POST["image_back"];
    $image_profile = $_POST["image_profile"];
    $logo_vitesse = $_POST["logo_vitesse"];
    $vitesse = $_POST["vitesse"];
    $prix = $_POST["prix"];
    $logo_prix = $_POST["logo_prix"];
    $mini_description = $_POST["mini_description"];
    $description_interieur = $_POST["description_interieur"];
    $description_exterieur = $_POST["description_exterieur"];



    $image_interieur1 = 'images/'. $image_interieur;


    $image_front1 = 'images/'. $image_front;


    $image_back1 = 'images/'. $image_back;


    $image_profile1 = 'images/'. $image_profile;


    $logo_vitesse1 = 'images/'. $logo_vitesse;


    $logo_prix1 = 'images/'. $logo_prix;


    $logo_marque1 = 'images/'. $logo_marque;




// Prepare your SQL query to insert data into the "CONTACT" table
    $insertQuery = "INSERT INTO VOITURE (marque, modele, annee, logo_marque,image_interieur,image_front,image_back,image_profile,logo_vitesse,vitesse,prix,logo_prix,mini_description,description_interieur,description_exterieur) VALUES ('$marque', '$modele','$annee','$logo_marque1','$image_interieur1','$image_front1','$image_back1','$image_profile1','$logo_vitesse1','$vitesse','$prix','$logo_prix1','$mini_description','$description_interieur','$description_exterieur')";

    // Execute the query using mysqli_query
    if (mysqli_query($bdd, $insertQuery)) {
        echo "Registration successful!";
    } else {
        echo "Error: " . mysqli_error($bdd);
    }
}
?>

<div class="container one p-5">
<a href="a_menu_voiture.html">Retour</a>   
<h4 class="text-center fw-bold">Ajout de voiture</h4>

   <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
   <div class="row mb-3">
        <div class="col-md-4">
            <label for="marque" class="form-label">Marque</label>
            <input type="text" name="marque" class="form-control" placeholder="Marque" required>
        </div>
        <div class="col-md-4">
            <label for="modele" class="form-label">Modéle</label>
            <input type="text" name="modele" class="form-control" placeholder="modèle" required>
        </div>
        <div class="col-md-4">
            <label for="modele" class="form-label">Année</label>
            <input type="text" name="annee" class="form-control" placeholder="année" required>
        </div>
        <div class="mb-3">
            <label for="mini_description" class="form-label">Mini Description</label>
            <textarea name="mini_description" class="form-control" rows="5"placeholder="Mini Description" required></textarea>
        </div>
        <div class="mb-3">
            <label for="description_interieur" class="form-label">Description Interieur</label>
            <textarea name="description_interieur" class="form-control" rows="5"placeholder="Description Interieur" required></textarea>
        </div>
        <div class="mb-3">
            <label for="description_exterieur" class="form-label">Description Exterieur</label>
            <textarea name="description_exterieur" class="form-control" rows="5"placeholder="Description Exterieur" required></textarea>
        </div>
        <div class="col-md-6">
                    <label for="inputGroupFile02" class="form-label">Image interieur</label>
                    <input type="file" class="form-control" name="image_interieur" required>
        </div>
        <div class="col-md-6">
                    <label for="inputGroupFile02" class="form-label">Image Front</label>
                    <input type="file" class="form-control" name="image_front" required>
        </div>
        <div class="col-md-6">
                    <label for="inputGroupFile02" class="form-label">Image Back</label>
                    <input type="file" class="form-control" name="image_back" required>
        </div>
        <div class="col-md-6">
                    <label for="inputGroupFile02" class="form-label">Image Profile</label>
                    <input type="file" class="form-control" name="image_profile" required>
        </div>
        <div class="col-md-6">
            <label for="vitesse" class="form-label">Vitesse</label>
            <input type="text" name="vitesse" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label for="prix" class="form-label">Prix</label>
            <input type="text" name="prix" class="form-control" required>
        </div>
        <div class="col-md-4">
                    <label for="inputGroupFile02" class="form-label">Logo Vitesse</label>
                    <input type="file" class="form-control" name="logo_vitesse" required>
        </div>
        <div class="col-md-4">
                    <label for="inputGroupFile02" class="form-label">Logo Marque</label>
                    <input type="file" class="form-control" name="logo_marque" required>
        </div>
        <div class="col-md-4">
                    <label for="inputGroupFile02" class="form-label">Logo Prix</label>
                    <input type="file" class="form-control" name="logo_prix" required>
        </div>
        <button type="submit" name="update" class="form-control button mt-4 red">Mettre à jour</button>
    </div> 
    <div id="status">
                <?php
                // Affichage du message de statut dans le champ dédié
                if (isset($status)) {
                    echo $status;
                }
                ?>
    </div>
    </form>  
</div>   
        
</body>
</html>
