<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Modification Voiture </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>



<?php
include("connexion.php");

$error_message = "";

// Traitement du formulaire lorsque l'utilisateur clique sur "Update"
if(isset($_POST['update'])) {

    // Récupération des données du formulaire
    $id_voiture = htmlspecialchars($_POST['id_voiture']);
    $marque = htmlspecialchars($_POST['marque']);
    $modele = htmlspecialchars($_POST['modele']);
    $annee = htmlspecialchars($_POST['annee']);
    $mini_description = htmlspecialchars($_POST['mini_description']);
    $description_interieur = htmlspecialchars($_POST['description_interieur']);
    $description_exterieur = htmlspecialchars($_POST['description_exterieur']);
    $vitesse = htmlspecialchars($_POST['vitesse']);
    $prix = htmlspecialchars($_POST['prix']);
    $logo_vitesse = htmlspecialchars($_POST['logo_vitesse']);
    $logo_marque = htmlspecialchars($_POST['logo_marque']);
    $logo_prix = htmlspecialchars($_POST['logo_prix']);

    // Gestion des images (vérification si une nouvelle image a été uploadée)
    $image_interieur2 = !empty($_FILES['image_interieur1']['name']) ? 'images/' . $_FILES['image_interieur1']['name'] : htmlspecialchars($_POST['image_interieur']);
    $image_front2 = !empty($_FILES['image_front1']['name']) ? 'images/' . $_FILES['image_front1']['name'] : htmlspecialchars($_POST['image_front']);
    $image_back2 = !empty($_FILES['image_back1']['name']) ? 'images/' . $_FILES['image_back1']['name'] : htmlspecialchars($_POST['image_back']);
    $image_profile2 = !empty($_FILES['image_profile1']['name']) ? 'images/' . $_FILES['image_profile1']['name'] : htmlspecialchars($_POST['image_profile']);

    // Vérification des champs obligatoires
    if(empty($marque) || empty($modele) || empty($annee) || empty($mini_description) || empty($description_exterieur) || empty($description_interieur) || empty($vitesse) || empty($prix)) {
        $error_message = "All fields are required.";
    } else {
        // Préparation de la requête SQL de mise à jour
        $stmt = mysqli_prepare($bdd, "UPDATE voiture SET marque=?, modele=?, annee=?, mini_description=?, description_interieur=?, description_exterieur=?, vitesse=?, prix=?, image_interieur=?, image_front=?, image_back=?, image_profile=?, logo_vitesse=?, logo_marque=?, logo_prix=? WHERE id_voiture=?");
        mysqli_stmt_bind_param($stmt, "sssssssssssssssi", $marque, $modele, $annee, $mini_description, $description_interieur, $description_exterieur, $vitesse, $prix, $image_interieur2, $image_front2, $image_back2, $image_profile2, $logo_vitesse, $logo_marque, $logo_prix, $id_voiture);

        // Exécution de la requête SQL
        if(mysqli_stmt_execute($stmt)) {
            // Déplacer les fichiers uploadés vers le dossier images
            if (!empty($_FILES['image_interieur1']['name'])) {
                move_uploaded_file($_FILES['image_interieur1']['tmp_name'], $image_interieur2);
            }
            if (!empty($_FILES['image_front1']['name'])) {
                move_uploaded_file($_FILES['image_front1']['tmp_name'], $image_front2);
            }
            if (!empty($_FILES['image_back1']['name'])) {
                move_uploaded_file($_FILES['image_back1']['tmp_name'], $image_back2);
            }
            if (!empty($_FILES['image_profile1']['name'])) {
                move_uploaded_file($_FILES['image_profile1']['tmp_name'], $image_profile2);
            }

            // Fermeture de la requête et redirection
            mysqli_stmt_close($stmt);
            header("Location: a_voiture_modifier.php");
            exit();
        } else {
            $error_message = "Failed to update the vehicle.";
        }

        mysqli_stmt_close($stmt);
    }
}

// Récupération des données de la voiture à modifier
$id_voiture = htmlspecialchars($_GET['id_voiture']);
$result = mysqli_query($bdd, "SELECT * FROM voiture WHERE id_voiture=$id_voiture");

// Vérifier si la voiture existe
if(mysqli_num_rows($result) == 0) {
    // Gestion du cas où la voiture n'existe pas
    echo "Vehicle not found.";
    exit();
}

// Extraction des données de la voiture
$res = mysqli_fetch_array($result);
$marque = htmlspecialchars($res['marque']);
$modele = htmlspecialchars($res['modele']);
$annee = htmlspecialchars($res['annee']);
$mini_description = htmlspecialchars($res['mini_description']);
$description_interieur = htmlspecialchars($res['description_interieur']);
$description_exterieur = htmlspecialchars($res['description_exterieur']);
$image_interieur = htmlspecialchars($res['image_interieur']);
$image_front = htmlspecialchars($res['image_front']);
$image_back = htmlspecialchars($res['image_back']);
$image_profile = htmlspecialchars($res['image_profile']);
$vitesse = htmlspecialchars($res['vitesse']);
$logo_marque = htmlspecialchars($res['logo_marque']);
$logo_prix = htmlspecialchars($res['logo_prix']);
$prix = htmlspecialchars($res['prix']);
$logo_vitesse = htmlspecialchars($res['logo_vitesse']);

?>

    <div class="container one p-4">
        <a href="a_voiture_modifier.php">Retour</a>
        <h4 class="text-center fw-bold">Modification</h4>

        <!-- Formulaire de modification -->
        <form name="form1" method="post" action="a_voiture_modif.php" enctype="multipart/form-data" class="mt-4">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="marque" class="form-label">Marque</label>
                    <input type="text" name="marque" class="form-control" value="<?php echo $marque; ?>" required>
                </div>

                <div class="col-md-4">
                    <label for="modele" class="form-label">Modèle</label>
                    <input type="text" name="modele" class="form-control" value="<?php echo $modele; ?>">
                </div>

                <div class="col-md-4">
                    <label for="annee" class="form-label">Année</label>
                    <input type="number" name="annee" class="form-control" value="<?php echo $annee; ?>">
                </div>

                <div class="mb-3">
                    <label for="mini_description" class="form-label">Mini Description</label>
                    <textarea name="mini_description" class="form-control" rows="5"><?php echo $mini_description; ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="description_interieur" class="form-label">Description Intérieure</label>
                    <textarea name="description_interieur" class="form-control" rows="4"><?php echo $description_interieur; ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="description_exterieur" class="form-label">Description Extérieure</label>
                    <textarea name="description_exterieur" class="form-control" rows="4"><?php echo $description_exterieur; ?></textarea>
                </div>

                <!-- Gestion des images -->
                <div class="col-md-3">
                    <label for="image_interieur" class="form-label">Image Intérieure (actuelle)</label>
                    <input type="text" class="form-control" id="image_interieur" name="image_interieur" value="<?php echo $image_interieur; ?>" readonly>
                    <input type="file" class="form-control mt-2" name="image_interieur1">
                </div>

                <div class="col-md-3">
                    <label for="image_front" class="form-label">Image Front (actuelle)</label>
                    <input type="text" class="form-control" id="image_front" name="image_front" value="<?php echo $image_front; ?>" readonly>
                    <input type="file" class="form-control mt-2" name="image_front1">
                </div>

                <div class="col-md-3">
                    <label for="image_back" class="form-label">Image Arrière (actuelle)</label>
                    <input type="text" class="form-control" id="image_back" name="image_back" value="<?php echo $image_back; ?>" readonly>
                    <input type="file" class="form-control mt-2" name="image_back1">
                </div>

                <div class="col-md-3">
                    <label for="image_profile" class="form-label">Image Profil (actuelle)</label>
                    <input type="text" class="form-control" id="image_profile" name="image_profile" value="<?php echo $image_profile; ?>" readonly>
                    <input type="file" class="form-control mt-2" name="image_profile1">
                </div>

                <!-- Autres champs -->
                <div class="col-md-3">
                    <label for="logo_vitesse" class="form-label">Logo Vitesse</label>
                    <input type="text" class="form-control" id="logo_vitesse" name="logo_vitesse" value="<?php echo $logo_vitesse; ?>" required>
                </div>

                <div class="col-md-3">
                    <label for="vitesse" class="form-label">Vitesse</label>
                    <input type="text" name="vitesse" class="form-control" value="<?php echo $vitesse; ?>" required>
                </div>

                <div class="col-md-3">
                    <label for="logo_prix" class="form-label">Logo Prix</label>
                    <input type="text" class="form-control" id="logo_prix" name="logo_prix" value="<?php echo $logo_prix; ?>" required>
                </div>

                <div class="col-md-3">
                    <label for="prix" class="form-label">Prix</label>
                    <input type="number" name="prix" class="form-control" value="<?php echo $prix; ?>" required>
                </div>

                <div class="col-md-3">
                    <label for="logo_marque" class="form-label">Logo Marque</label>
                    <input type="text" class="form-control" id="logo_marque" name="logo_marque" value="<?php echo $logo_marque; ?>" required>
                </div>

                <!-- Champ caché pour l'id de la voiture -->
                <input type="hidden" name="id_voiture" value="<?php echo $id_voiture; ?>">

                <!-- Bouton de mise à jour -->
                <div class="col-12 mt-4">
                    <button type="submit" name="update" class="form-control button red">Update</button>
                </div>
            </div>
        </form>

        <!-- Affichage d'un message d'erreur si nécessaire -->
        <?php if(!empty($error_message)) { ?>
            <div class="alert alert-danger mt-3"><?php echo $error_message; ?></div>
        <?php } ?>
    </div>
</body>
</html>


