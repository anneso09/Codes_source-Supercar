<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Modification Voitures </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<link href = "a_style_menu.css" rel="stylesheet">
</HEAD>

<?php
include("connexion.php");
$result = mysqli_query($bdd, "SELECT * FROM voiture ORDER BY id_voiture ASC");
?>

<html>
<head>    
    <title>Modifier les voitures</title>
</head>
 
<body>
<div class="container one p-5">
<a href="a_menu_voiture.html">Retour</a>
<h4 class="text-center fw-bold">Veuillez modifier la voiture de votre chois</h4>
    <br />
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Année</th>
                <th>Action</th>
            </tr>
        </thead>
        
        <tbody>
            <?php 
            while($res = mysqli_fetch_array($result)) {         
                echo "<tr>";
                echo "<td>".$res['id_voiture']."</td>";
                echo "<td>".$res['marque']."</td>";
                echo "<td>".$res['modele']."</td>";
                echo "<td>".$res['annee']."</td>"; 
                echo "<td><a href=\"a_voiture_modif.php?id_voiture=".$res['id_voiture']."\">Modifier</a></td>";       
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
