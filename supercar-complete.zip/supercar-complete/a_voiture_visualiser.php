<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualiser Voitures</title>

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Style personnalisé -->
    <link href="a_style_menu.css" rel="stylesheet">
</head>
<body>
<div class="container on p-5">
    <a href="a_menu_voiture.html">Retour au Menu</a>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Identifiant</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Année</th>
                <th>Mini Description</th>
                <th>Description Intérieure</th>
                <th>Description Extérieure</th>
                <th>Vitesse</th>
                <th>Prix</th>
            </tr>
        </thead>
        <tbody>
        <?php
        include("connexion.php");
        $result = mysqli_query($bdd, "SELECT * FROM voiture ORDER BY id_voiture DESC");

        while ($res = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $res['id_voiture'] . "</td>";
            echo "<td>" . $res['marque'] . "</td>";
            echo "<td>" . $res['modele'] . "</td>";
            echo "<td>" . $res['annee'] . "</td>";
            echo "<td>" . $res['mini_description'] . "</td>";
            echo "<td>" . $res['description_interieur'] . "</td>";
            echo "<td>" . $res['description_exterieur'] . "</td>";
            echo "<td>" . $res['vitesse'] . "</td>";
            echo "<td>" . $res['prix'] . "</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
