<!--VOIR PDF-->

<!DOCTYPE HTML>

<HTML>
<HEAD>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

    <!--CSS de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <link href = "c_style_accueil.css" rel="stylesheet">
    <link href ="c_style_forms.css" rel = "stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <title> Inscription </title>

</HEAD>

<BODY>

    <!--DEBUT NAVBAR-->
    <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto">
            <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
            Supercar
        </a>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2 " aria-current="page" href="c_accueil.php">Accueil</a>
                    </li>
                    

                    <?php

                    include("connexion.php");

                        $query = "SELECT distinct marque FROM VOITURE";
                        $result = mysqli_query($bdd, $query);


                            if (!$result) {
                                die("Query failed: " . mysqli_error($bdd));
                                }
                    ?>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-lg-2 dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Voitures</a>
                                <ul class="dropdown-menu">
                                    <?php
          
                                    while ($row = mysqli_fetch_assoc($result)) {
                                    $marque = $row['marque'];
                                    $lien_voiture = "c_voiture_marque.php?marque=" . strtolower($marque);
                                    ?>
                                    <li><a class="dropdown-item" href="<?php echo $lien_voiture; ?>"><?php echo $marque; ?></a></li>
                                    <?php
                                        }
                                    ?>
                                </ul>
                    </li>

                    <?php

                        mysqli_close($bdd);
                    ?>


                   <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_services.php">Services</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_demande.php">Demande d'essai</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_contact.php">Contact</a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
        
        <a href="c_inscription.php" class="login-button"> Inscription </a>
        <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
    </nav>
    <!--FIN NAVBAR-->
<?php
// Include the database connection
include("connexion.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize input
    $nom = htmlspecialchars($_POST["nom"]);
    $prenom = htmlspecialchars($_POST["prenom"]);
    $email = htmlspecialchars($_POST["email"]);
    $numero = htmlspecialchars($_POST["numero"]);
    $username = htmlspecialchars($_POST["username"]);
    $password = $_POST["mdp"];
    $confirmpasswrd = $_POST["confirmpasswrd"];

    // Check if passwords match
    if ($password === $confirmpasswrd) {
        // Hash the password (you should use a stronger hashing algorithm in a real-world scenario)
        $hashedPassword = md5($password);

        // Prepare your SQL query to insert data into the "INSCRIPTION" table
        $insertQuery = "INSERT INTO INSCRIPTION (nom, prenom, email, numero, username, password) VALUES ('$nom', '$prenom', '$email', '$numero', '$username', '$hashedPassword')";

        // Execute the query using mysqli_query
        if (mysqli_query($bdd, $insertQuery)) {
            $status = "Enregistrement réussi!";
        } else {
            $status = "Error: " . mysqli_error($bdd);
        }
    } else {
        // Passwords do not match
        $status = "Les mots de passe ne correspondent pas.";
    }
}

// Close the database connection
mysqli_close($bdd);
?>

<div class="container">
    <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="mb-3 bg p-5">
            <h2 class="text-center fw-bold"> Inscrivez-vous </h2>
            

            <div class="row">
                <div class="col">
                    <label for="nom" class="form-label mt-3">Nom</label>
                    <input type="text" class="form-control" name="nom" required>
                </div>
                <div class="col">
                    <label for="prenom" class="form-label mt-3">Prénom</label>
                    <input type="text" class="form-control" name="prenom" required>
                </div>
            </div>


            <label for="numero de telephone" class="form-label mt-2">Numéro de téléphone</label>
            <input type="tel" class="form-control" name="numero" required>

            <label for="email" class="form-label mt-2">Adresse mail</label>
            <input type="email" class="form-control" name="email" required>

            <label for="username" class="form-label mt-2">Nom d'utilisateur</label>
            <input type="text" class="form-control" name="username" required>

            <label for="password" class="form-label mt-2">Mot de passe </label>
            <input type="password" class="form-control" name="mdp" required>

            <label for="confirmpasswrd" class="form-label mt-2"> Confirmer le mot de passe</label>
            <input type="password" class="form-control" name="confirmpasswrd" required>

         
            <div class="row ">
                <div class="col">
                    <button type="submit" class="form-control button mt-3 btn">S'enregistrer</button>
                </div>
                <div class="col">
                    <button type="reset" class="form-control button mt-3 btn">Annuler</button>
                </div>

                <div id="status" text-white>
        <?php
            // Display status message in the dedicated field
            if (isset($status)) {
                echo $status;
            }
        ?>
    </div>
            </div>

            
            
        </div>
        
    </form>
</div>







</body>
</html>