<!--service.php-->
<!DOCTYPE HTML>

<HTML>
<HEAD>
	<meta charset = "UTF-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

	<!--CSS de Bootstrap-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

	<link href = "c_style_accueil.css" rel="stylesheet">
    <link href = "c_style_forms.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">

    <title> Services </title>
</HEAD>


<BODY>

	<!--DEBUT NAVBAR-->
    <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto">
            <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
            Supercar
        </a>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" aria-current="page" href="c_accueil.php">Accueil</a>
                    </li>
                    
                    <?php
                    include("connexion.php");
                        $query = "SELECT distinct marque FROM VOITURE";
                        $result = mysqli_query($bdd, $query);
                            if (!$result) {
                                die("Query failed: " . mysqli_error($bdd));
                                }
                    ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link mx-lg-2 dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Voitures</a>
                                <ul class="dropdown-menu">
                                
                                <?php
                                    while ($row = mysqli_fetch_assoc($result)) {
                                    $marque = $row['marque'];
                                    $lien_voiture = "c_voiture_marque.php?marque=" . strtolower($marque);
                                ?>
                                    <li><a class="dropdown-item" href="<?php echo $lien_voiture; ?>"><?php echo $marque; ?></a></li>
                                    <?php
                                        }
                                    ?>
                                </ul>
                    </li>

                    <?php

                        mysqli_close($bdd);
                    ?>


                   <li class="nav-item">
                        <a class="nav-link mx-lg-2 active" href="c_services.php">Services</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_demande.php">Demande d'essai</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_contact.php">Contact</a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
        
        <a href="c_inscription.php" class="login-button"> Inscription </a>
        <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
    </nav>
    <!--FIN NAVBAR-->

	<!--DEBUT HERO SECTION-->
	<section class="hero-section" style="background: url(images/cars.jpg) no-repeat center; ; background-size: cover;">
        <div class="container d-flex align-items-center justify-content-center fs-1 text-white flex column">
            <h2>Est. 2009</h2>
        </div>
    </section>

	<!--FIN HERO SECTION-->




    <?php
        include("connexion.php");
        $selection = "SELECT image,type_service, description_service FROM p_service";
        $curseur = mysqli_query($bdd, $selection);


        if ($curseur) {
    // Assurez-vous qu'il y a des résultats à afficher
            if (mysqli_num_rows($curseur) > 0) {
                while ($row = mysqli_fetch_array($curseur)) {
                    $v_image = $row["image"];
                    $v_type_service = $row["type_service"];
                    $v_description = $row["description_service"];

                    echo "<div class='container-fluid mt-3 mx-auto'>";
                    echo "<div class='row'>";

                    echo "<div class='col-sm-4'><img src='$v_image' width='100%'></div>";
                    echo "<div class='col-sm-4 p-3 milieu'>";
                    echo "<div class='container-fluid'>
                        <h5> $v_type_service </h5>
                        <p> $v_description </p>
                    </div>
                  </div>";
        }

        // Libérer la mémoire du serveur de la variable $curseur
        mysqli_free_result($curseur);
            } else {
        // Gérer le cas où la requête ne renvoie pas de résultats
                echo "Aucun résultat trouvé.";
                }
        } else {
    // Gérer l'erreur si la requête échoue
    echo "Erreur de requête : " . mysqli_error($bdd);
        }
        ?>
	
        <?php
    // Define your database connection credentials
    include("connexion.php");

    // Function to validate login
    function validateLogin($bdd, $username, $password, $p_field_type, $p_date) {
        // Use prepared statements to prevent SQL injection
        $stmt = $bdd->prepare("SELECT id_inscription FROM INSCRIPTION WHERE username = ? AND password = ?");
        $hashpassword = md5($password);
        $stmt->bind_param("ss", $username, $hashpassword);
        $stmt->execute();
        $result = $stmt->get_result();
        $status1 = '';

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $id_inscription = $row['id_inscription'];

            $stmtInsert = $bdd->prepare("INSERT INTO service (type_service, date_service, id_inscription) VALUES (?, ?, ?)");

// Check if prepare() succeeded
if ($stmtInsert === false) {
    die("Prepare failed: " . htmlspecialchars($bdd->error));
}

// Bind parameters
$success = $stmtInsert->bind_param("ssi", $p_field_type, $p_date, $id_inscription);

// Check if bind_param() succeeded
if ($success === false) {
    die("Binding parameters failed: " . htmlspecialchars($stmtInsert->error));
}

// Execute the query
if ($stmtInsert->execute()) {
    $status1 .= "Données insérées avec succès !";
} else {
    $status1 .= "Échec de l'insertion des données. Erreur : " . $stmtInsert->error;
}

$stmtInsert->close();

            return true; // Valid login
        } else {
            return false; // Invalid login
        }
    }

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $mdp = $_POST["mdp"];
        $date = $_POST["date_service"];
        $field_type = $_POST["field_type"];

        // Validate the login
        if (validateLogin($bdd, $username, $mdp, $field_type, $date)) {
            $status = "Connexion réussie !";
        } else {
            $status = "Nom d'utilisateur ou mot de passe incorrect.";
        }

        // Close the database connection
        $bdd->close();
    }
?>


<div class="container">
    <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="mb-3 bg p-5">
            <h2 class="text-center fw-bold">Envoyez-nous votre demande de service</h2>
            <p class="text-center"><em>Veuillez noter que vous devez être client chez Supercar avant de procéder à une demande de service</em>
                <a class="text-center" href="c_inscription.php">Faites votre inscription</a>
            </p>
            <hr size="10" color="black">
            
            <div class="row mb-3">
                <div class="col">
                    <label for="username" class="form-label mt-3">Nom d'utilisateur</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="col">
                    <label for="password" class="form-label mt-3">Mot de passe</label>
                    <input type="password" class="form-control" name="mdp" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="date" class="form-label mt-2">Date pour votre rendez-vous</label>
                    <input type="date" name="date_service" class="form-control" required>
                </div>
                <div class="col">
                    <?php
                    // Include the database connection file
                    include("connexion.php");

                    // Prepare and execute the query to select car models
                    $selection = "SELECT type_service FROM p_service";
                    $curseur = mysqli_query($bdd, $selection);

                    // Check if the query executed successfully
                    if ($curseur) {
                        echo "<label for='field_type' class='form-label mt-2'>Service de votre choix</label>";
                        echo "<select name='field_type' class='form-control' required>";
                        echo "<option value=''>...</option>";
                        
                        // Loop through results to populate the dropdown
                        while ($row = mysqli_fetch_array($curseur)) {
                            $type = $row["type_service"];
                            echo "<option>$type</option>";
                        }

                        echo "</select>";
                    } else {
                        // Display error message if query fails
                        echo "Erreur lors de l'exécution de la requête : " . mysqli_error($bdd);
                    }

                    // Close the database connection
                    mysqli_close($bdd);
                    ?>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <button type="submit" class="form-control button mt-5 btn">Envoyer</button>
                </div>
                <div class="col">
                    <button type="reset" class="form-control button mt-5 btn">Annuler</button>
                </div>
                <div id="status">
                    <?php
                    // Display status message
                    if (isset($status)) {
                        echo $status;
                    }
                    ?>
                </div>
            </div>
        </div>

        <div id="status">
            <?php
            // Display status message
            if (isset($status)) {
                echo $status;
            }
            ?>
        </div>
    </form>
</div>

		  	
	<!--FIN CONTENU DE LA PAGE-->

	<!--DEBUT DU FOOTER-->
	<footer class="bg-dark mt-5 bottom">
    <div class="container p-4 text-light">
        <small class="text-white-50"> Supercar </small>
        <small class="text-white-50">&copy; Copyright by Supercar </small>
        <div class="container-fluid mt-3">
            <div class="container-fluid mt-3">
                <div class="row footer justify-content-center">
                    <div class="col p-4 text-white text-center"><a href = "#"> Mentions Légales</a></div>
                    <div class="col p-4 text-white text-center"><a href = "#">Politique de confidentialité</a></div>
                    <div class="col p-4 text-white text-center"><a href = "#">Contact</a></div>
                </div>
            </div>
        </div>
    </div>
</footer>


</BODY>

</HTML>	